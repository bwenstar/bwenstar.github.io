upa-check: run UPA-tamper's detector without the sensor
========================================================

From https://brendanta.com (post: "Ten samples on one side").

  upa_test.go   Go tests that call the detector in UPA-tamper's main.go directly
  cap1000       1,000 frames of gyro samples from the board, sitting still (6 KB)
  cap10000      10,000 frames, same format (59 KB)

The captures are raw little-endian signed 16-bit values, repeating Gx, Gy, Gz.

To run (needs Go 1.16 or later):

  git clone https://github.com/brendan-ta/UPA-tamper
  cp upa_test.go cap1000 cap10000 UPA-tamper/
  cd UPA-tamper
  go mod init upa-tamper      # the repo has no go.mod
  go test -v

TestCaptures  feeds both captures through all three axes (expect 0 tampers)
TestTurn      simulates a 2 s turn at 2.6, 3.1 and 30 degrees/s
TestFigure    writes figure.csv, the data behind the post's figure

Tested with Go 1.18 (golang:1.18-alpine Docker image).
