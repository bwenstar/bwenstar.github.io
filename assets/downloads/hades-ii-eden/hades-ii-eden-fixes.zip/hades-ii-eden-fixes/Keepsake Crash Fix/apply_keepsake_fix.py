#!/usr/bin/env python3
"""Make the Hades II v0 keepsake crash fix from your own copy of Scripts/KeepsakeLogic.lua.

  python3 apply_keepsake_fix.py KeepsakeLogic.lua

Writes "romfs/Scripts/KeepsakeLogic.lua" next to this script. Copy the whole
"Keepsake Crash Fix" folder into Eden's load/0100A00019DE0000/ folder.
Only for the base game (v0): don't use it on an updated game.
"""
import pathlib
import sys

FIXES = [
    # UnequipKeepsake(nil) when no keepsake was equipped before: do nothing
    (b"\tlocal unit = heroUnit or CurrentRun.Hero\r\n\tif traitName == \"ArmorGainKeepsake\"",
     b"\tlocal unit = heroUnit or CurrentRun.Hero\r\n\tif traitName == nil then\r\n\t\treturn\r\n\tend\r\n"
     b"\tif traitName == \"ArmorGainKeepsake\""),
    # line 186: don't index TraitData with an unknown name
    (b"\tif TraitData[traitName].Permanent and not CanFreeSwapKeepsakes()",
     b"\tif TraitData[traitName] and TraitData[traitName].Permanent and not CanFreeSwapKeepsakes()"),
]

if len(sys.argv) != 2:
    sys.exit(__doc__)
data = pathlib.Path(sys.argv[1]).read_bytes()
for old, new in FIXES:
    if data.count(old) != 1:
        sys.exit("This doesn't look like the v0 KeepsakeLogic.lua (or it's already patched); nothing written.")
    data = data.replace(old, new)
out = pathlib.Path(__file__).resolve().parent / "romfs" / "Scripts" / "KeepsakeLogic.lua"
out.parent.mkdir(parents=True, exist_ok=True)
out.write_bytes(data)
print(f"Wrote {out}")
