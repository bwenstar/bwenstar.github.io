Hades II crash fixes for the Eden Switch emulator
https://brendanta.com/2026/10/25/hades-ii-eden-crashes.html

Software Opus Fix/
  Stops the 2010-0011 crash (room transitions, save select). One instruction in
  the game's main executable is changed so the game uses its own software Opus
  decoder instead of the hardware one. One .ips per game build:
    5219053E5EB156BE80FBB2F3037795317BEA8C2F.ips  base game (v0), tested
    CF8DDAAB2D318451FD0CEECA0F627E610C96440E.ips  update v458752 (Eden: v0.7.0);
                                                  same bytes at the same offset
  Copy the "Software Opus Fix" folder into
    <Eden data>/load/0100A00019DE0000/
  (Linux: ~/.local/share/eden/load/0100A00019DE0000/)

Keepsake Crash Fix/  (base game v0 only)
  Stops the 2162-0001 crash when closing the keepsake screen. The game's script
  isn't included; extract Scripts/KeepsakeLogic.lua from your own copy of the
  game's RomFS, then run:
    python3 "Keepsake Crash Fix/apply_keepsake_fix.py" KeepsakeLogic.lua
  and copy the "Keepsake Crash Fix" folder into the same load/ folder.
  Don't use it on an updated game: it would replace the update's own script.

Then in Eden: right-click Hades II > Properties > Add-ons, tick the fixes.
You need your own copy of the game. Nothing from the game is in this zip.
